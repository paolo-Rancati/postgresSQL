CREATE TABLE address (
	address_id SERIAL PRIMARY KEY,
	house_no int NULL,
	street varchar(255) NULL,
	zipcode int NOT NULL
);

CREATE TABLE basement_type (
	basement_id SERIAL PRIMARY KEY,
	basement_desc varchar(255) NULL
);

CREATE TABLE heat_type (
	heat_id SERIAL PRIMARY KEY,
	heat_desc varchar(255) NULL
);

CREATE TABLE evaluation (
	evaluation_id serial primary KEY,
	year_built int NULL,
	land_value int NULL,
	total_value int NULL,
	wellness_rating int NULL
);

CREATE TABLE property_class (
	class_id int primary KEY,
	class_desc varchar(255)
);

CREATE TABLE police_district(
	police_district varchar(255) NOT NULL,
	no_violent_crimes int NOT NULL,
	no_property_crimes int NOT NULL,
	violent_crime_rate numeric(4,2) NOT NULL,
	property_crime_rate numeric(4,2) NOT NULL,
	PRIMARY KEY (police_district)
);


CREATE TABLE customers(
	customer_id SERIAL primary KEY,
	customer_name varchar(255) NOT NULL,
	customer_email varchar(255),
	customer_phone varchar(255)
);

CREATE TABLE property_specs (
	property_specs_id SERIAL primary KEY,
	heat_type_id int,
	basement_type_id int,
	no_stories int NULL,
	no_baths int NULL,
	sq_footage int NULL,
FOREIGN KEY (heat_type_id) REFERENCES heat_type(heat_id) ON DELETE SET NULL ON UPDATE CASCADE,
FOREIGN KEY (basement_type_id) REFERENCES basement_type(basement_id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE property_details (
	property_id SERIAL PRIMARY KEY,
	class_id int NOT NULL,
	owner_id int NULL,
	police_district varchar(255) NULL,
	address_id int NOT NULL,
	evaluation_id int NOT NULL,
	property_specs_id int NOT NULL,
	for_sale bool NULL,
FOREIGN KEY (class_id) REFERENCES property_class(class_id) ON DELETE SET NULL ON UPDATE CASCADE,
FOREIGN KEY (owner_id) REFERENCES customers(customer_id) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (police_district) REFERENCES police_district(police_district) ON DELETE SET NULL ON UPDATE cascade,
FOREIGN KEY (address_id) REFERENCES address(address_id) ON DELETE SET NULL ON UPDATE cascade,
FOREIGN KEY (evaluation_id) REFERENCES evaluation(evaluation_id) ON DELETE SET NULL ON UPDATE cascade,
FOREIGN KEY (property_specs_id) REFERENCES property_specs(property_specs_id) ON DELETE SET NULL ON UPDATE cascade
);


