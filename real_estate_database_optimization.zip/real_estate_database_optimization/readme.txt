
A. Steps to Create the tables:
	
 Step 1: Download the create.sql file available in the same directory as this file.

 Step 2: Run the DDL commands present in create.sql in the same order as present in the file.



B. Steps to Load data into the tables:

  Step 1: Download all the .csv files present in the same directory as this file.

  Step 2: Download load.sql available in the same directory as this file.
 
  Step 3: For each command in load.sql, please make sure to replace the file <PATH> with the path where the .csv file is downloaded in your system.

  Step 4: Open psql tool (Note: please make sure to open psql tool and not query tool).

  Step 5: Run each command present in load.sql in the psql tool in the same order as present in the file.
	  Note: each of the 9 commands should be executed separately in psql tool.



C. Data Source:

   The data source is based on city of Buffalo’s property assessment of 2019 available at https://data.buffalony.gov/Government/2019-2020-Assessment-Roll/kckn-jafw