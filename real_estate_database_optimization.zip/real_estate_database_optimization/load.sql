
\copy heat_type FROM '/Users/harman/Desktop/DMQL_project/heat_type.csv' DELIMITER ',' CSV HEADER;

\copy basement_type FROM '/Users/harman/Desktop/DMQL_project/basement_type.csv' DELIMITER ',' CSV HEADER;

\copy police_district FROM '/Users/harman/Desktop/DMQL_project/police_district.csv' DELIMITER ',' CSV HEADER;

\copy property_class FROM '/Users/harman/Desktop/DMQL_project/property_class.csv' DELIMITER ',' CSV HEADER;

\copy address FROM '/Users/harman/Desktop/DMQL_project/address.csv' DELIMITER ',' CSV HEADER;

\copy customers FROM '/Users/harman/Desktop/DMQL_project/customers.csv' DELIMITER ',' CSV HEADER;

\copy evaluation FROM '/Users/harman/Desktop/DMQL_project/evaluation.csv' DELIMITER ',' CSV HEADER;

\copy property_specs FROM '/Users/harman/Desktop/DMQL_project/property_specs.csv' DELIMITER ',' CSV HEADER;

\copy property_details FROM '/Users/harman/Desktop/DMQL_project/property_details.csv' DELIMITER ',' CSV HEADER;
